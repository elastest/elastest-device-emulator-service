from setuptools import setup

setup(
    #...,
    tests_require=['pytest','nosetests'],
    #...,
)